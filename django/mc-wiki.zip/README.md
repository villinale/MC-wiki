# MC-wiki
### 文件路径说明：

  HTML文件存放处：mc_wiki/wiki/templates

  图片，js，css静态文件存放处：mc_wiki/wiki/static 

  路由定义：mc_wiki/wiki/urls.py

  逻辑实现：mc_wiki/wiki/views.py
  
###  脚本运行指令：
  进入目录mc_wiki/mc_wiki/后
  
  终端输入：python manage.py runserver
