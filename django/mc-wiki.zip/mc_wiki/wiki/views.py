from django.shortcuts import render
from django.http import JsonResponse, HttpResponseNotAllowed, HttpResponse
import os
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
BASE_DIR = BASE_DIR.replace('\\', '/')
BASE_DIR += '/templates'
# 该文件直接访问templates
# 主页面
def main_interface(request):
    return render(request, './web/main.html')

# 地形
def topography(request):
    return render(request, './web/topography.html')

# 物品页面
def item_interface(request):
    return render(request, './web/mc_item.html')

# 生物界面
def biology(request):
    return render(request, './web/biology.html')

# 生物处理
def biology_solve(request, type):
    path = './web/biology/' + str(type) + '.html'
    if not os.path.exists(BASE_DIR+path[1:]):
        return render(request, './web/item/introduce_not_find.html')
    return render(request, path)

# 公告
def Notice(request):
    return render(request, './web/placard.html')


def item_solve(request, type, item_id):
    path = './web/item/'+type+ '/' + str(item_id) + '.html'
    # print(path)
    if not os.path.exists(BASE_DIR+path[1:]):
        return render(request, './web/item/introduce_not_find.html')

    return render(request, path)

# 默认处理与错误处理
def default_solve(request, type):
    if type == "introduce":
        return render(request, './web/item/introduce_default.html')

    pass


def test_debug(request):
    return render(request, './web/test.html')
